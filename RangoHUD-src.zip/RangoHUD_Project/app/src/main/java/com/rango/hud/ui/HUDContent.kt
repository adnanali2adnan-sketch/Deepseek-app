package com.rango.hud.ui
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.detectDragGestures
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.rango.hud.ai.DeepSeekPredictor
import com.rango.hud.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HUDContent(
    viewModel: MainViewModel,
    onDragStart: () -> Unit,
    onDrag: (Float, Float) -> Unit,
    onDragEnd: () -> Unit,
    onOCRTrigger: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val gameMode by viewModel.gameMode.collectAsState()
    val last8Rounds by viewModel.last8Rounds.collectAsState()
    val streakAnalysis = remember { viewModel.getStreakAnalysis() }
    val apiKey by viewModel.deepSeekApiKey.collectAsState()
    val walletBalance by viewModel.walletBalance.collectAsState()
    var showSettings by remember { mutableStateOf(false) }
    var showPrediction by remember { mutableStateOf(false) }
    var predictionText by remember { mutableStateOf("Tap 'Get AI Prediction'") }

    Card(modifier = Modifier.width(360.dp).shadow(8.dp).pointerInput(Unit) {
        detectDragGestures(
            onDragStart = { onDragStart() },
            onDrag = { change, dragAmount -> change.consume(); onDrag(dragAmount.x, dragAmount.y) },
            onDragEnd = { onDragEnd() }
        )
    }, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = SpaceCard)) {
        Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
            // Header
            Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DragHandle, null, tint = TextGray)
                    Spacer(Modifier.width(8.dp))
                    Text("RANGO HUD", color = GoldAccent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.width(8.dp))
                    Surface(shape = RoundedCornerShape(4.dp), color = if (gameMode == "DragonTiger") DragonBlue else DeepPurple, modifier = Modifier.clickable { viewModel.setGameMode(if (gameMode == "DragonTiger") "Crash" else "DragonTiger") }) {
                        Text(if (gameMode == "DragonTiger") "🐉 DT" else "✈️ Crash", fontSize = 10.sp, color = TextWhite, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
                Row {
                    IconButton(onClick = { showSettings = true }, modifier = Modifier.size(28.dp)) { Icon(Icons.Default.Settings, null, tint = TextGray, modifier = Modifier.size(16.dp)) }
                    IconButton(onClick = { showPrediction = true }, modifier = Modifier.size(28.dp)) { Icon(Icons.Default.Psychology, null, tint = GoldAccent, modifier = Modifier.size(16.dp)) }
                }
            }
            Spacer(Modifier.height(8.dp))
            // Timeline
            Text("Recent Results", color = TextGray, fontSize = 10.sp)
            Spacer(Modifier.height(4.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                items(last8Rounds.takeLast(8)) { round ->
                    if (gameMode == "DragonTiger") {
                        Surface(shape = RoundedCornerShape(4.dp), color = when (round.result) { "Dragon" -> DragonBlue; "Tiger" -> TigerRed; else -> TiePurple }, modifier = Modifier.size(32.dp)) {
                            Box(contentAlignment = Alignment.Center) { Text(text = when (round.result) { "Dragon" -> "D"; "Tiger" -> "T"; else -> "P" }, color = TextWhite, fontWeight = FontWeight.Bold) }
                        }
                    } else {
                        Surface(shape = RoundedCornerShape(4.dp), color = DeepPurple, modifier = Modifier.padding(4.dp)) { Text("${round.result}x", color = TextWhite, fontSize = 12.sp) }
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            if (gameMode == "DragonTiger" && streakAnalysis.currentStreak > 0) {
                Row(modifier = Modifier.fillMaxWidth().background(DragonBlue.copy(alpha = 0.2f), RoundedCornerShape(4.dp)).padding(6.dp)) {
                    Text("🔥 ${streakAnalysis.currentLeader} streak: ${streakAnalysis.currentStreak}", color = GoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(6.dp))
            }
            // Input buttons
            if (gameMode == "DragonTiger") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { viewModel.addRound("Dragon") }, colors = ButtonDefaults.buttonColors(containerColor = LimeGreen), modifier = Modifier.weight(1f), contentPadding = PaddingValues(8.dp)) { Text("🐉 DRAGON", color = androidx.compose.ui.graphics.Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                    Button(onClick = { viewModel.addRound("Tie") }, colors = ButtonDefaults.buttonColors(containerColor = DeepPurple), modifier = Modifier.weight(0.7f), contentPadding = PaddingValues(8.dp)) { Text("TIE", color = TextWhite, fontSize = 12.sp) }
                    Button(onClick = { viewModel.addRound("Tiger") }, colors = ButtonDefaults.buttonColors(containerColor = NeonRed), modifier = Modifier.weight(1f), contentPadding = PaddingValues(8.dp)) { Text("🐯 TIGER", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                }
            } else {
                var multiplierText by remember { mutableStateOf("") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(value = multiplierText, onValueChange = { multiplierText = it }, placeholder = { Text("Multiplier", color = TextGray) }, modifier = Modifier.weight(1f), textStyle = LocalTextStyle.current.copy(color = TextWhite, fontSize = 12.sp))
                    Button(onClick = { multiplierText.toDoubleOrNull()?.let { viewModel.addCrashRound(it) }; multiplierText = "" }, colors = ButtonDefaults.buttonColors(containerColor = DeepPurple)) { Text("ADD", color = TextWhite) }
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { viewModel.undoLast() }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(6.dp)) { Icon(Icons.Default.Undo, null, Modifier.size(14.dp)); Spacer(Modifier.width(4.dp)); Text("UNDO", fontSize = 11.sp) }
                OutlinedButton(onClick = { viewModel.clearAll() }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(6.dp)) { Icon(Icons.Default.Delete, null, Modifier.size(14.dp)); Spacer(Modifier.width(4.dp)); Text("CLEAR", fontSize = 11.sp) }
                Button(onClick = { onOCRTrigger() }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(6.dp), colors = ButtonDefaults.buttonColors(containerColor = DragonBlue)) {
                    Icon(Icons.Default.CameraAlt, null, Modifier.size(14.dp)); Spacer(Modifier.width(4.dp)); Text("OCR SCAN", fontSize = 10.sp, color = TextWhite)
                }
            }
        }
    }
    // Settings Dialog
    if (showSettings) {
        Dialog(onDismissRequest = { showSettings = false }) {
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = SpaceCard), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Settings", color = GoldAccent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(value = apiKey ?: "", onValueChange = { viewModel.setDeepSeekApiKey(it) }, label = { Text("DeepSeek API Key", color = TextGray) }, textStyle = LocalTextStyle.current.copy(color = TextWhite), singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { showSettings = false }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = GoldAccent)) { Text("Close", color = androidx.compose.ui.graphics.Color.Black) }
                }
            }
        }
    }
    // Prediction Dialog
    if (showPrediction) {
        Dialog(onDismissRequest = { showPrediction = false }) {
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = SpaceCard), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("🤖 DeepSeek AI Analysis", color = GoldAccent, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(predictionText, color = TextWhite, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {
                        if (apiKey.isNullOrEmpty()) predictionText = "❌ Please add DeepSeek API Key in Settings"
                        else {
                            scope.launch {
                                predictionText = "Analyzing..."
                                val predictor = DeepSeekPredictor(context)
                                val result = predictor.getPrediction(apiKey!!, viewModel.last20Rounds.value, gameMode, walletBalance)
                                predictionText = result.getOrElse { "API Error: ${it.message}" }
                            }
                        }
                    }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = DeepPurple)) { Text("Get AI Prediction", color = TextWhite) }
                }
            }
        }
    }
}
