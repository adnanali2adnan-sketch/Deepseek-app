package com.rango.hud.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "rounds")
data class RoundEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val result: String, val timestamp: Long = System.currentTimeMillis(), val gameMode: String)
