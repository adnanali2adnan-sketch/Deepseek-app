package com.rango.hud.ocr
import android.content.Context
import android.graphics.Bitmap
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
class ScreenCaptureHelper(private val context: Context) {
    private var mediaProjection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    suspend fun captureAndRecognize(resultCode: Int, data: android.content.Intent): String = suspendCancellableCoroutine { continuation ->
        val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)
        val display = context.display ?: return@suspendCancellableCoroutine
        val width = display.width; val height = display.height
        imageReader = ImageReader.newInstance(width, height, android.graphics.ImageFormat.RGBA_8888, 2)
        mediaProjection?.createVirtualDisplay("ScreenCapture", width, height, context.resources.displayMetrics.densityDpi, android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader?.surface, null, null)
        val handler = Handler(Looper.getMainLooper())
        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage()
            if (image != null) {
                val buffer = image.planes[0].buffer
                val bitmap = Bitmap.createBitmap(image.width, image.height, Bitmap.Config.ARGB_8888)
                bitmap.copyPixelsFromBuffer(buffer)
                image.close()
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                val inputImage = InputImage.fromBitmap(bitmap, 0)
                recognizer.process(inputImage).addOnSuccessListener { visionText ->
                    val text = visionText.text.lowercase()
                    val result = when { text.contains("dragon") -> "Dragon"; text.contains("tiger") -> "Tiger"; text.contains("tie") || text.contains("平局") -> "Tie"; else -> "" }
                    continuation.resume(result); stopCapture()
                }.addOnFailureListener { continuation.resume(""); stopCapture() }
            }
        }, handler)
    }
    private fun stopCapture() { imageReader?.close(); mediaProjection?.stop(); imageReader = null; mediaProjection = null }
}
