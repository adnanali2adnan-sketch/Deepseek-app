package com.rango.hud.viewmodel
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rango.hud.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getInstance(application)
    private val repository = Repository(db.roundDao())
    private val prefs = PreferencesManager(application)
    private val _gameMode = MutableStateFlow("DragonTiger")
    val gameMode: StateFlow<String> = _gameMode
    val last8Rounds = _gameMode.flatMapLatest { mode -> repository.getLast8Rounds(mode) }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val last20Rounds = _gameMode.flatMapLatest { mode -> repository.getLast20Rounds(mode) }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val deepSeekApiKey = prefs.getDeepSeekApiKey().stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val walletBalance = prefs.getWalletBalance().stateIn(viewModelScope, SharingStarted.Eagerly, 1000.0)
    init { viewModelScope.launch { prefs.getGameMode().collect { _gameMode.value = it } } }
    fun addRound(result: String) { viewModelScope.launch { repository.addRound(result, _gameMode.value) } }
    fun addCrashRound(multiplier: Double) { viewModelScope.launch { repository.addRound(multiplier.toString(), "Crash") } }
    fun undoLast() { viewModelScope.launch { repository.undoLast(_gameMode.value) } }
    fun clearAll() { viewModelScope.launch { repository.clearAll(_gameMode.value) } }
    fun setGameMode(mode: String) { viewModelScope.launch { prefs.setGameMode(mode) } }
    fun setDeepSeekApiKey(key: String) { viewModelScope.launch { prefs.saveDeepSeekApiKey(key) } }
    suspend fun setWalletBalance(balance: Double) { prefs.saveWalletBalance(balance) }
    fun getStreakAnalysis(): StreakResult {
        val rounds = last20Rounds.value.take(20)
        var currentStreak = 0; var currentWinner = ""; var maxStreak = 0; var maxStreakWinner = ""
        for (round in rounds) {
            if (round.result == "Dragon" || round.result == "Tiger") {
                if (round.result == currentWinner) currentStreak++
                else { if (currentStreak > maxStreak) { maxStreak = currentStreak; maxStreakWinner = currentWinner }; currentWinner = round.result; currentStreak = 1 }
            }
        }
        return StreakResult(currentStreak, currentWinner, maxStreak, maxStreakWinner)
    }
}
data class StreakResult(val currentStreak: Int, val currentLeader: String, val maxStreak: Int, val maxStreakLeader: String)
