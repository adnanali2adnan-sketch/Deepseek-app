package com.rango.hud

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.rango.hud.ocr.ScreenCaptureHelper
import com.rango.hud.ui.HUDContent
import com.rango.hud.viewmodel.MainViewModel
import kotlinx.coroutines.launch

class OverlayService : LifecycleService() {
    private lateinit var windowManager: WindowManager
    private lateinit var hudView: ComposeView
    private lateinit var viewModel: MainViewModel
    private var layoutParams: WindowManager.LayoutParams? = null
    private var initialX = 0
    private var initialY = 0
    private var mediaProjectionManager: MediaProjectionManager? = null
    private var screenCaptureHelper: ScreenCaptureHelper? = null
    private var pendingOCRResult: Intent? = null
    companion object {
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "rango_hud_channel"
        private const val REQUEST_MEDIA_PROJECTION = 100
    }
    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        viewModel = MainViewModel(application)
        mediaProjectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureHelper = ScreenCaptureHelper(this)
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification())
        setupOverlayView()
    }
    private fun setupOverlayView() {
        hudView = ComposeView(this).apply {
            setContent {
                HUDContent(viewModel,
                    onDragStart = { onDragStart() },
                    onDrag = { dx, dy -> onDrag(dx, dy) },
                    onDragEnd = { onDragEnd() },
                    onOCRTrigger = { startOCR() }
                )
            }
        }
        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 100; y = 200 }
        windowManager.addView(hudView, layoutParams)
    }
    private fun onDragStart() { layoutParams?.let { initialX = it.x; initialY = it.y } }
    private fun onDrag(dx: Float, dy: Float) { layoutParams?.let { it.x = initialX + dx.toInt(); it.y = initialY + dy.toInt(); windowManager.updateViewLayout(hudView, it) } }
    private fun onDragEnd() { layoutParams?.let { initialX = it.x; initialY = it.y } }
    private fun startOCR() { if (pendingOCRResult == null) { val intent = mediaProjectionManager?.createScreenCaptureIntent(); if (intent != null) startActivityForResult(intent, REQUEST_MEDIA_PROJECTION) } else performOCR() }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) { super.onActivityResult(requestCode, resultCode, data); if (requestCode == REQUEST_MEDIA_PROJECTION && resultCode == RESULT_OK && data != null) { pendingOCRResult = data; performOCR() } }
    private fun performOCR() { lifecycleScope.launch { try { val result = pendingOCRResult; if (result != null) { val recognizedText = screenCaptureHelper?.captureAndRecognize(RESULT_OK, result) ?: ""; if (recognizedText.isNotEmpty()) viewModel.addRound(recognizedText); pendingOCRResult = null } } catch (e: Exception) { e.printStackTrace() } } }
    private fun createNotificationChannel() { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { val channel = NotificationChannel(CHANNEL_ID, "Rango HUD Service", NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager::class.java).createNotificationChannel(channel) } }
    private fun createNotification(): Notification = NotificationCompat.Builder(this, CHANNEL_ID).setContentTitle("Rango HUD Active").setContentText("Floating overlay running").setSmallIcon(android.R.drawable.ic_menu_edit).setPriority(NotificationCompat.PRIORITY_LOW).build()
    override fun onDestroy() { super.onDestroy(); if (::hudView.isInitialized) windowManager.removeView(hudView) }
    override fun onBind(intent: Intent?): IBinder? = null
}
