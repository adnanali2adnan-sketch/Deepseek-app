package com.rango.hud.ai
import android.content.Context
import com.rango.hud.data.RoundEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
class DeepSeekPredictor(private val context: Context) {
    private val client = OkHttpClient.Builder().connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS).readTimeout(30, java.util.concurrent.TimeUnit.SECONDS).build()
    private val API_URL = "https://api.deepseek.com/v1/chat/completions"
    suspend fun getPrediction(apiKey: String, recentRounds: List<RoundEntity>, gameMode: String, walletBalance: Double): Result<String> = withContext(Dispatchers.IO) {
        try {
            val history = recentRounds.take(20).joinToString(", ") { it.result }
            val prompt = if (gameMode == "DragonTiger") "Analyze Dragon Tiger sequence: [$history]. Wallet: $$walletBalance. Give next hand prediction (Dragon/Tiger/Tie), confidence %, bet size %. Keep short."
            else "Analyze Crash multipliers: [$history]. Wallet: $$walletBalance. Recommend cashout multiplier and risk level. Keep short."
            val jsonBody = JSONObject().put("model", "deepseek-chat").put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", "You are a casino game analyst.")).put(JSONObject().put("role", "user").put("content", prompt))).put("temperature", 0.7).put("max_tokens", 200)
            val request = Request.Builder().url(API_URL).addHeader("Authorization", "Bearer $apiKey").addHeader("Content-Type", "application/json").post(jsonBody.toString().toRequestBody("application/json".toMediaType())).build()
            val response = client.newCall(request).execute()
            val body = response.body?.string()
            if (response.isSuccessful && body != null) { val prediction = JSONObject(body).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content"); Result.success(prediction) }
            else Result.failure(Exception("API error: ${response.code}"))
        } catch (e: Exception) { Result.failure(e) }
    }
}
