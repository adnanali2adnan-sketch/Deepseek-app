package com.rango.hud

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.rango.hud.ocr.ScreenCaptureHelper
import com.rango.hud.ui.HUDContent
import com.rango.hud.viewmodel.MainViewModel
import kotlinx.coroutines.launch

class OverlayService : LifecycleService() {
    private lateinit var windowManager: WindowManager
    private lateinit var hudView: ComposeView
    private lateinit var viewModel: MainViewModel
    private var layoutParams: WindowManager.LayoutParams? = null
    private var initialX = 0
    private var initialY = 0
    private var screenCaptureHelper: ScreenCaptureHelper? = null

    companion object {
        private const val NOTIFICATION_ID = 9912
        private const val CHANNEL_ID = "rango_hud_channel"
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        viewModel = MainViewModel(application)
        screenCaptureHelper = ScreenCaptureHelper(this)
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification())
        setupOverlayView()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val projectionData = intent?.getParcelableExtra<Intent>("PROJECTION_INTENT")
        if (projectionData != null) {
            lifecycleScope.launch {
                screenCaptureHelper?.initializeProjectionStream(Activity.RESULT_OK, projectionData)
            }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    private fun setupOverlayView() {
        hudView = ComposeView(this).apply {
            setContent {
                HUDContent(
                    viewModel = viewModel,
                    onDragStart = { onDragStart() },
                    onDrag = { dx, dy -> onDrag(dx, dy) },
                    onDragEnd = { onDragEnd() },
                    onOCRTrigger = { triggerOcrFrameExtraction() }
                )
            }
        }
        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 200
        }
        windowManager.addView(hudView, layoutParams)
    }

    private fun onDragStart() {
        layoutParams?.let { params -> initialX = params.x; initialY = params.y }
    }

    private fun onDrag(dx: Float, dy: Float) {
        layoutParams?.let { params ->
            params.x = initialX + dx.toInt()
            params.y = initialY + dy.toInt()
            windowManager.updateViewLayout(hudView, params)
        }
    }

    private fun onDragEnd() {
        layoutParams?.let { params -> initialX = params.x; initialY = params.y }
    }

    private fun triggerOcrFrameExtraction() {
        lifecycleScope.launch {
            val evaluatedText = screenCaptureHelper?.captureAndRecognize() ?: ""
            if (evaluatedText.isNotEmpty()) { viewModel.addRound(evaluatedText) }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Rango HUD Service", NotificationManager.IMPORTANCE_LOW)
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Rango HUD Active")
            .setContentText("Hardware Pilot Matrix Running")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        screenCaptureHelper?.stopCapture()
        if (::hudView.isInitialized) { windowManager.removeView(hudView) }
    }
    override fun onBind(intent: Intent?): IBinder? = null
}