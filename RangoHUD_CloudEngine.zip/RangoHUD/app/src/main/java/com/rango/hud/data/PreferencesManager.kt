package com.rango.hud.data
import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("rango_settings")
class PreferencesManager(private val context: Context) {
    companion object {
        val DEEPSEEK_API_KEY = stringPreferencesKey("deepseek_api_key")
        val WALLET_BALANCE = doublePreferencesKey("wallet_balance")
        val GAME_MODE = stringPreferencesKey("game_mode")
    }
    suspend fun saveDeepSeekApiKey(key: String) { context.dataStore.edit { it[DEEPSEEK_API_KEY] = key } }
    fun getDeepSeekApiKey(): Flow<String?> = context.dataStore.data.map { it[DEEPSEEK_API_KEY] }
    suspend fun saveWalletBalance(balance: Double) { context.dataStore.edit { it[WALLET_BALANCE] = balance } }
    fun getWalletBalance(): Flow<Double> = context.dataStore.data.map { it[WALLET_BALANCE] ?: 1000.0 }
    suspend fun setGameMode(mode: String) { context.dataStore.edit { it[GAME_MODE] = mode } }
    fun getGameMode(): Flow<String> = context.dataStore.data.map { it[GAME_MODE] ?: "DragonTiger" }
}