package com.rango.hud.ai
import android.content.Context
import com.rango.hud.data.RoundEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class DeepSeekPredictor(private val context: Context) {
    private val client = OkHttpClient.Builder().build()
    private val API_URL = "https://api.deepseek.com/v1/chat/completions"
    
    suspend fun getPrediction(apiKey: String, recentRounds: List<RoundEntity>, gameMode: String, walletBalance: Double): Result<String> = withContext(Dispatchers.IO) {
        try {
            val history = recentRounds.take(15).joinToString(", ") { it.result }
            val prompt = if (gameMode == "DragonTiger") {
                "Analyze Sequence: [$history]. Wallet: \$$walletBalance. Output format strictly: NEXT HAND: [Dragon/Tiger/SKIP] | CONFIDENCE: [X%] | SYSTEM BET: [X]. Keep single line."
            } else {
                "Analyze Multipliers: [$history]. Wallet: \$$walletBalance. Output format strictly: CRASH TARGET: [X.XXx] | RISK EVALUATION: [LOW/MEDIUM/HIGH]. Keep single line."
            }
            val jsonBody = JSONObject().apply {
                put("model", "deepseek-chat")
                put("messages", JSONArray().apply {
                    put(JSONObject().apply { put("role", "system"); put("content", "You are an expert math telemetry processor.") })
                    put(JSONObject().apply { put("role", "user"); put("content", prompt) })
                })
                put("temperature", 0.1)
                put("max_tokens", 80)
            }
            val request = Request.Builder().url(API_URL).addHeader("Authorization", "Bearer $apiKey").addHeader("Content-Type", "application/json").post(jsonBody.toString().toRequestBody("application/json".toMediaType())).build()
            val response = client.newCall(request).execute()
            val body = response.body?.string()
            if (response.isSuccessful && body != null) {
                val prediction = JSONObject(body).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
                Result.success(prediction)
            } else Result.failure(Exception("HTTP Error: \${response.code}"))
        } catch (e: Exception) { Result.failure(e) }
    }
}