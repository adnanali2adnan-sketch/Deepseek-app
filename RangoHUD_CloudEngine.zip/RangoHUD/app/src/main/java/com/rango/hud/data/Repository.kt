package com.rango.hud.data
import kotlinx.coroutines.flow.Flow

class Repository(private val dao: RoundDao) {
    fun getLast20Rounds(mode: String): Flow<List<RoundEntity>> = dao.getLast20Rounds(mode)
    fun getLast8Rounds(mode: String): Flow<List<RoundEntity>> = dao.getLast8Rounds(mode)
    suspend fun addRound(result: String, mode: String) = dao.insert(RoundEntity(result = result, gameMode = mode))
    suspend fun undoLast(mode: String) = dao.deleteLastRound(mode)
    suspend fun clearAll(mode: String) = dao.clearAllRounds(mode)
}