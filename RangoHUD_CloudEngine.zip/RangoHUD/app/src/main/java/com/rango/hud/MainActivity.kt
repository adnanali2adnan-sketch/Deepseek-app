package com.rango.hud

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rango.hud.ui.SpaceDark
import com.rango.hud.ui.TextWhite

class MainActivity : ComponentActivity() {
    private var pendingMediaProjectionIntent: Intent? = null
    
    private val projectionPermissionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            pendingMediaProjectionIntent = result.data
            executeServiceLaunch()
        }
    }

    private val overlayPermissionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        triggerMediaProjectionRequest()
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = SpaceDark, background = SpaceDark)) {
                MainScreen(onStartOverlay = {
                    if (Settings.canDrawOverlays(this)) {
                        triggerMediaProjectionRequest()
                    } else {
                        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                        overlayPermissionLauncher.launch(intent)
                    }
                })
            }
        }
    }
    
    private fun triggerMediaProjectionRequest() {
        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionPermissionLauncher.launch(mpManager.createScreenCaptureIntent())
    }

    private fun executeServiceLaunch() {
        val intent = Intent(this, OverlayService::class.java).apply {
            putExtra("PROJECTION_INTENT", pendingMediaProjectionIntent)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        finish()
    }
}

@Composable
fun MainScreen(onStartOverlay: () -> Unit) {
    Surface(modifier = Modifier.fillMaxSize(), color = SpaceDark) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("🎮 RANGO COMPANION HUD", style = MaterialTheme.typography.headlineMedium, color = TextWhite)
            Spacer(Modifier.height(24.dp))
            Text("Advanced Dragon Tiger & Crash Analyzer", color = TextWhite.copy(alpha = 0.7f))
            Spacer(Modifier.height(48.dp))
            Button(onClick = onStartOverlay) { Text("Launch Floating HUD Matrix") }
        }
    }
}