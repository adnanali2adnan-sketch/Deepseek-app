package com.rango.hud.ui
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.rango.hud.ai.DeepSeekPredictor
import com.rango.hud.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HUDContent(viewModel: MainViewModel, onDragStart: () -> Unit, onDrag: (Float, Float) -> Unit, onDragEnd: () -> Unit, onOCRTrigger: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val gameMode by viewModel.gameMode.collectAsState()
    val last8Rounds by viewModel.last8Rounds.collectAsState()
    val streakAnalysis = viewModel.getStreakAnalysis()
    val apiKey by viewModel.deepSeekApiKey.collectAsState()
    val walletBalance by viewModel.walletBalance.collectAsState()
    
    var showSettings by remember { mutableStateOf(false) }
    var showPrediction by remember { mutableStateOf(false) }
    var predictionText by remember { mutableStateOf("Tap 'Execute Prediction Matrix'") }
    
    Card(modifier = Modifier.width(340.dp).pointerInput(Unit) {
        detectDragGestures(onDragStart = { onDragStart() }, onDrag = { change, dragAmount -> change.consume(); onDrag(dragAmount.x, dragAmount.y) }, onDragEnd = { onDragEnd() })
    }, shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = SpaceCard)) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DragHandle, contentDescription = null, tint = TextGray, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("RANGO ENGINE", color = GoldAccent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(Modifier.width(6.dp))
                    Surface(shape = RoundedCornerShape(4.dp), color = if (gameMode == "DragonTiger") DragonBlue else DeepPurple, modifier = Modifier.clickable {
                        viewModel.setGameMode(if (gameMode == "DragonTiger") "Crash" else "DragonTiger")
                    }) {
                        Text(text = if (gameMode == "DragonTiger") "🐉 DT" else "✈️ Crash", fontSize = 10.sp, color = TextWhite, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
                Row {
                    IconButton(onClick = { showSettings = true }, modifier = Modifier.size(26.dp)) { Icon(Icons.Default.Settings, null, tint = TextGray, modifier = Modifier.size(16.dp)) }
                    IconButton(onClick = { showPrediction = true }, modifier = Modifier.size(26.dp)) { Icon(Icons.Default.Psychology, null, tint = GoldAccent, modifier = Modifier.size(16.dp)) }
                }
            }
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                items(last8Rounds) { round ->
                    Surface(shape = RoundedCornerShape(4.dp), color = if (gameMode == "DragonTiger") (when(round.result) { "Dragon" -> DragonBlue; "Tiger" -> TigerRed; else -> TiePurple }) else DeepPurple) {
                        Text(text = if (gameMode == "DragonTiger") round.result.take(1) else "\${round.result}x", color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp))
                    }
                }
            }
            if (gameMode == "DragonTiger" && streakAnalysis.currentStreak > 0) {
                Spacer(Modifier.height(6.dp))
                Text("🔥 Current Sequence: \${streakAnalysis.currentLeader} x\${streakAnalysis.currentStreak}", color = GoldAccent, fontSize = 11.sp)
            }
            Spacer(Modifier.height(8.dp))
            if (gameMode == "DragonTiger") {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = { viewModel.addRound("Dragon") }, colors = ButtonDefaults.buttonColors(containerColor = DragonBlue), modifier = Modifier.weight(1f)) { Text("D", color = TextWhite) }
                    Button(onClick = { viewModel.addRound("Tie") }, colors = ButtonDefaults.buttonColors(containerColor = TiePurple)) { Text("P") }
                    Button(onClick = { viewModel.addRound("Tiger") }, colors = ButtonDefaults.buttonColors(containerColor = TigerRed), modifier = Modifier.weight(1f)) { Text("T", color = TextWhite) }
                }
            } else {
                var crashInput by remember { mutableStateOf("") }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = crashInput, onValueChange = { crashInput = it }, modifier = Modifier.weight(1f).height(48.dp), placeholder = { Text("1.00", fontSize = 11.sp) }, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite))
                    Button(onClick = { crashInput.toDoubleOrNull()?.let { viewModel.addCrashRound(it) }; crashInput = "" }) { Text("ADD") }
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { viewModel.undoLast() }, modifier = Modifier.weight(1f)) { Text("UNDO", fontSize = 10.sp) }
                OutlinedButton(onClick = { viewModel.clearAll() }, modifier = Modifier.weight(1f)) { Text("CLEAR", fontSize = 10.sp) }
                Button(onClick = onOCRTrigger, colors = ButtonDefaults.buttonColors(containerColor = LimeGreen)) { Text("OCR SCAN", color = SpaceDark, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
    if (showSettings) {
        Dialog(onDismissRequest = { showSettings = false }) {
            Card(colors = CardDefaults.cardColors(containerColor = SpaceCard)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Configuration Terminal", color = GoldAccent, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = apiKey ?: "", onValueChange = { viewModel.setDeepSeekApiKey(it) }, label = { Text("DeepSeek Key") }, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite))
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = walletBalance.toString(), onValueChange = { it.toDoubleOrNull()?.let { b -> viewModel.setWalletBalance(b) } }, label = { Text("Balance (\$)") }, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite))
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { showSettings = false }, modifier = Modifier.fillMaxWidth()) { Text("Save Settings") }
                }
            }
        }
    }
    if (showPrediction) {
        Dialog(onDismissRequest = { showPrediction = false }) {
            Card(colors = CardDefaults.cardColors(containerColor = SpaceCard)) {
                Column(Modifier.padding(16.dp)) {
                    Text("🤖 Intelligence Telemetry Feed", color = GoldAccent, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Text(predictionText, color = TextWhite, fontSize = 12.sp, lineHeight = 16.sp)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = {
                        if (apiKey.isNullOrEmpty()) { predictionText = "ERR: Set DeepSeek Token Key inside System Terminals." } else {
                            scope.launch {
                                predictionText = "Analyzing sequence flows..."
                                val predictor = DeepSeekPredictor(context)
                                val result = predictor.getPrediction(apiKey!!, viewModel.last20Rounds.value, gameMode, walletBalance)
                                predictionText = result.getOrElse { "Execution Error: \${it.message}" }
                            }
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Execute Prediction Matrix") }
                }
            }
        }
    }
}