package com.rango.hud.ocr
import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.regex.Pattern
import kotlin.coroutines.resume

class ScreenCaptureHelper(private val context: Context) {
    private var mediaProjection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val multiplierPattern = Pattern.compile("\(\\d+[.,]\\d{1,2})\\s*x?\")

    fun initializeProjectionStream(resultCode: Int, data: android.content.Intent) {
        val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)
    }
    
    suspend fun captureAndRecognize(): String = suspendCancellableCoroutine { continuation ->
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager
        val display = dm.getDisplay(0) ?: return@suspendCancellableCoroutine
        val metrics = android.util.DisplayMetrics()
        display.getRealMetrics(metrics)
        
        imageReader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
        mediaProjection?.createVirtualDisplay("ScreenCapture", metrics.widthPixels, metrics.heightPixels, metrics.densityDpi, 1, imageReader?.surface, null, null)
        
        val handler = Handler(Looper.getMainLooper())
        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage()
            if (image != null) {
                val planes = image.planes
                val buffer = planes[0].buffer
                val bitmap = Bitmap.createBitmap(image.width, image.height, Bitmap.Config.ARGB_8888)
                bitmap.copyPixelsFromBuffer(buffer)
                image.close()
                stopCapture()

                val cropY = (metrics.heightPixels * 0.02).toInt()
                val cropHeight = (metrics.heightPixels * 0.12).toInt()
                val croppedBitmap = Bitmap.createBitmap(bitmap, 0, cropY, metrics.widthPixels, cropHeight)

                val inputImage = InputImage.fromBitmap(croppedBitmap, 0)
                recognizer.process(inputImage).addOnSuccessListener { visionText ->
                    val text = visionText.text.lowercase()
                    val matcher = multiplierPattern.matcher(text)
                    val result = when {
                        text.contains("dragon") -> "Dragon"
                        text.contains("tiger") -> "Tiger"
                        text.contains("tie") -> "Tie"
                        matcher.find() -> matcher.group(1) ?: ""
                        else -> ""
                    }
                    continuation.resume(result)
                }.addOnFailureListener { continuation.resume("") }
            }
        }, handler)
    }
    fun stopCapture() { imageReader?.close(); imageReader = null }
}