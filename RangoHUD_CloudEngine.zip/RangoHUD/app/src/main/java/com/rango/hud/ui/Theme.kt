package com.rango.hud.ui
import androidx.compose.ui.graphics.Color

val SpaceDark = Color(0xFF0A0A1A)
val SpaceCard = Color(0xFF121F2B)
val DragonBlue = Color(0xFF0066FF)
val TigerRed = Color(0xFFFF3333)
val TiePurple = Color(0xFF9B30FF)
val LimeGreen = Color(0xFF32CD32)
val NeonRed = Color(0xFFFF4444)
val DeepPurple = Color(0xFF8B00FF)
val GoldAccent = Color(0xFFFFD700)
val TextWhite = Color(0xFFFFFFFF)
val TextGray = Color(0xFFB0B0B0)