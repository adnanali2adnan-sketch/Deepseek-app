package com.rango.hud.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface RoundDao {
    @Insert
    suspend fun insert(round: RoundEntity)
    
    @Query("SELECT * FROM rounds WHERE gameMode = :mode ORDER BY timestamp DESC LIMIT 20")
    fun getLast20Rounds(mode: String): Flow<List<RoundEntity>>
    
    @Query("SELECT * FROM rounds WHERE gameMode = :mode ORDER BY timestamp DESC LIMIT 8")
    fun getLast8Rounds(mode: String): Flow<List<RoundEntity>>
    
    @Query("DELETE FROM rounds WHERE id = (SELECT id FROM rounds WHERE gameMode = :mode ORDER BY timestamp DESC LIMIT 1)")
    suspend fun deleteLastRound(mode: String)
    
    @Query("DELETE FROM rounds WHERE gameMode = :mode")
    suspend fun clearAllRounds(mode: String)
}