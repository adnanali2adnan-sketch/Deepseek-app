package com.rango.hud.viewmodel
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rango.hud.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getInstance(application)
    private val repository = Repository(db.roundDao())
    private val prefs = PreferencesManager(application)
    private val _gameMode = MutableStateFlow("DragonTiger")
    val gameMode: StateFlow<String> = _gameMode
    
    val last8Rounds = _gameMode.flatMapLatest { repository.getLast8Rounds(it) }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val last20Rounds = _gameMode.flatMapLatest { repository.getLast20Rounds(it) }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val deepSeekApiKey = prefs.getDeepSeekApiKey().stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val walletBalance = prefs.getWalletBalance().stateIn(viewModelScope, SharingStarted.Eagerly, 1000.0)
    
    init { viewModelScope.launch { prefs.getGameMode().collect { _gameMode.value = it } } }
    fun addRound(result: String) { viewModelScope.launch { repository.addRound(result, _gameMode.value) } }
    fun addCrashRound(multiplier: Double) { viewModelScope.launch { repository.addRound(multiplier.toString(), "Crash") } }
    fun undoLast() { viewModelScope.launch { repository.undoLast(_gameMode.value) } }
    fun clearAll() { viewModelScope.launch { repository.clearAll(_gameMode.value) } }
    fun setGameMode(mode: String) { viewModelScope.launch { prefs.setGameMode(mode) } }
    fun setDeepSeekApiKey(key: String) { viewModelScope.launch { prefs.saveDeepSeekApiKey(key) } }
    fun setWalletBalance(balance: Double) { viewModelScope.launch { prefs.saveWalletBalance(balance) } }
    
    fun getStreakAnalysis(): StreakResult {
        val rounds = last20Rounds.value
        if (rounds.isEmpty()) return StreakResult(0, "None", 0, "None")
        var currentStreak = 1
        val currentWinner = rounds.first().result
        for (i in 1 until rounds.size) {
            if (rounds[i].result == currentWinner) currentStreak++ else break
        }
        return StreakResult(currentStreak, currentWinner, currentStreak, currentWinner)
    }
}
data class StreakResult(val currentStreak: Int, val currentLeader: String, val maxStreak: Int, val maxStreakLeader: String)