import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  SafeAreaView, StatusBar, Modal, Animated
} from 'react-native';
import FloatingHUD from './src/components/FloatingHUD';
import { analyzePattern } from './src/utils/patternAnalysis';
import type { Round, Prediction } from './src/types';

export default function App() {
  const [rounds, setRounds] = useState<Round[]>([]);
  const [prediction, setPrediction] = useState<Prediction | null>(null);
  const [hudVisible, setHudVisible] = useState(true);

  const addRound = (result: 'Dragon' | 'Tiger' | 'Tie') => {
    const newRounds = [...rounds, { id: Date.now(), result, timestamp: new Date() }];
    setRounds(newRounds);
    const pred = analyzePattern(newRounds);
    setPrediction(pred);
  };

  const undo = () => {
    const newRounds = rounds.slice(0, -1);
    setRounds(newRounds);
    setPrediction(newRounds.length > 0 ? analyzePattern(newRounds) : null);
  };

  const reset = () => { setRounds([]); setPrediction(null); };

  const dragon = rounds.filter(r => r.result === 'Dragon').length;
  const tiger = rounds.filter(r => r.result === 'Tiger').length;
  const tie = rounds.filter(r => r.result === 'Tie').length;
  const total = rounds.length;

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0a" />

      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>🐉 Dragon Tiger AI</Text>
        <TouchableOpacity onPress={() => setHudVisible(!hudVisible)} style={styles.hudToggle}>
          <Text style={styles.hudToggleText}>{hudVisible ? 'Hide HUD' : 'Show HUD'}</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Prediction Box */}
        <View style={[styles.predBox, {
          borderColor: prediction?.pick === 'Dragon' ? '#c0392b' :
                       prediction?.pick === 'Tiger' ? '#2471a3' : '#1e8449'
        }]}>
          {prediction ? (
            <>
              <Text style={styles.predLabel}>AI Prediction</Text>
              <Text style={[styles.predResult, {
                color: prediction.pick === 'Dragon' ? '#e74c3c' :
                       prediction.pick === 'Tiger' ? '#3498db' : '#2ecc71'
              }]}>
                {prediction.pick === 'Dragon' ? '🐉' : prediction.pick === 'Tiger' ? '🐯' : '🤝'} {prediction.pick}
              </Text>
              <Text style={styles.predConf}>{prediction.confidence}% confidence</Text>
              <Text style={styles.predReason}>{prediction.reason}</Text>
            </>
          ) : (
            <Text style={styles.predEmpty}>Enter results to get AI prediction</Text>
          )}
        </View>

        {/* Stats */}
        <View style={styles.statsRow}>
          <View style={[styles.statCard, { borderColor: '#c0392b' }]}>
            <Text style={styles.statNum}>{dragon}</Text>
            <Text style={styles.statLabel}>Dragon</Text>
            <Text style={styles.statPct}>{total > 0 ? Math.round(dragon/total*100) : 0}%</Text>
          </View>
          <View style={[styles.statCard, { borderColor: '#2471a3' }]}>
            <Text style={styles.statNum}>{tiger}</Text>
            <Text style={styles.statLabel}>Tiger</Text>
            <Text style={styles.statPct}>{total > 0 ? Math.round(tiger/total*100) : 0}%</Text>
          </View>
          <View style={[styles.statCard, { borderColor: '#1e8449' }]}>
            <Text style={styles.statNum}>{tie}</Text>
            <Text style={styles.statLabel}>Tie</Text>
            <Text style={styles.statPct}>{total > 0 ? Math.round(tie/total*100) : 0}%</Text>
          </View>
        </View>

        {/* Main Buttons */}
        <View style={styles.btnRow}>
          <TouchableOpacity style={[styles.mainBtn, { backgroundColor: '#c0392b' }]} onPress={() => addRound('Dragon')}>
            <Text style={styles.mainBtnIcon}>🐉</Text>
            <Text style={styles.mainBtnText}>Dragon</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.mainBtn, { backgroundColor: '#2471a3' }]} onPress={() => addRound('Tiger')}>
            <Text style={styles.mainBtnIcon}>🐯</Text>
            <Text style={styles.mainBtnText}>Tiger</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity style={[styles.tieBtn]} onPress={() => addRound('Tie')}>
          <Text style={styles.tieBtnText}>🤝 Tie</Text>
        </TouchableOpacity>

        {/* History */}
        <View style={styles.historySection}>
          <Text style={styles.historyTitle}>Round History ({total})</Text>
          <View style={styles.historyBubbles}>
            {rounds.slice(-30).reverse().map((r, i) => (
              <View key={r.id} style={[styles.bubble, {
                backgroundColor: r.result === 'Dragon' ? '#c0392b' :
                                  r.result === 'Tiger' ? '#2471a3' : '#1e8449'
              }]}>
                <Text style={styles.bubbleText}>
                  {r.result === 'Dragon' ? 'D' : r.result === 'Tiger' ? 'T' : 'X'}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Action Buttons */}
        <View style={styles.actionRow}>
          <TouchableOpacity style={styles.undoBtn} onPress={undo} disabled={rounds.length === 0}>
            <Text style={styles.actionBtnText}>↩ Undo</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.resetBtn} onPress={reset}>
            <Text style={styles.actionBtnText}>🗑 Reset</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Floating HUD */}
      {hudVisible && <FloatingHUD prediction={prediction} rounds={rounds} />}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0a' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, borderBottomWidth: 1, borderBottomColor: '#222' },
  headerTitle: { color: '#fff', fontSize: 20, fontWeight: 'bold' },
  hudToggle: { backgroundColor: '#222', padding: 8, borderRadius: 8 },
  hudToggleText: { color: '#aaa', fontSize: 12 },
  scroll: { flex: 1, padding: 16 },
  predBox: { backgroundColor: '#111', borderWidth: 2, borderRadius: 16, padding: 20, alignItems: 'center', marginBottom: 16 },
  predLabel: { color: '#888', fontSize: 12, marginBottom: 8 },
  predResult: { fontSize: 32, fontWeight: 'bold', marginBottom: 4 },
  predConf: { color: '#fff', fontSize: 16, marginBottom: 8 },
  predReason: { color: '#888', fontSize: 13, textAlign: 'center' },
  predEmpty: { color: '#555', fontSize: 15, textAlign: 'center', padding: 10 },
  statsRow: { flexDirection: 'row', gap: 8, marginBottom: 16 },
  statCard: { flex: 1, backgroundColor: '#111', borderWidth: 1, borderRadius: 12, padding: 12, alignItems: 'center' },
  statNum: { color: '#fff', fontSize: 24, fontWeight: 'bold' },
  statLabel: { color: '#888', fontSize: 11 },
  statPct: { color: '#aaa', fontSize: 12 },
  btnRow: { flexDirection: 'row', gap: 12, marginBottom: 12 },
  mainBtn: { flex: 1, borderRadius: 16, padding: 20, alignItems: 'center' },
  mainBtnIcon: { fontSize: 32 },
  mainBtnText: { color: '#fff', fontSize: 18, fontWeight: 'bold', marginTop: 4 },
  tieBtn: { backgroundColor: '#1e8449', borderRadius: 16, padding: 16, alignItems: 'center', marginBottom: 20 },
  tieBtnText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  historySection: { marginBottom: 16 },
  historyTitle: { color: '#888', fontSize: 13, marginBottom: 10 },
  historyBubbles: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  bubble: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  bubbleText: { color: '#fff', fontWeight: 'bold', fontSize: 13 },
  actionRow: { flexDirection: 'row', gap: 12, marginBottom: 30 },
  undoBtn: { flex: 1, backgroundColor: '#333', borderRadius: 12, padding: 14, alignItems: 'center' },
  resetBtn: { flex: 1, backgroundColor: '#333', borderRadius: 12, padding: 14, alignItems: 'center' },
  actionBtnText: { color: '#fff', fontWeight: '600' },
});
