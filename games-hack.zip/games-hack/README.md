# Dragon Tiger AI - Android APK

## Setup

1. Install dependencies:
```bash
npm install
```

2. (Optional) Add DeepSeek API key in `eas.json` under `env.DEEPSEEK_API_KEY`

3. Run locally:
```bash
npx expo start --android
```

## Build APK via GitHub Actions

See `.github/workflows/build.yml` — push to `main` branch to trigger.

Required GitHub Secret:
- `EXPO_TOKEN` — from https://expo.dev/accounts/[username]/settings/access-tokens

APK will appear in Actions → Artifacts after ~5-10 minutes.
