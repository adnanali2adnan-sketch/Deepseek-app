export type ResultType = 'Dragon' | 'Tiger' | 'Tie';

export interface Round {
  id: number;
  result: ResultType;
  timestamp: Date;
}

export interface Prediction {
  pick: ResultType;
  confidence: number;
  reason: string;
  pattern: string;
}
