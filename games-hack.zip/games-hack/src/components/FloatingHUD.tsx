import React, { useState, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Animated, PanResponder, Dimensions } from 'react-native';
import type { Prediction, Round } from '../types';

interface Props {
  prediction: Prediction | null;
  rounds: Round[];
}

const SCREEN = Dimensions.get('window');

export default function FloatingHUD({ prediction, rounds }: Props) {
  const [collapsed, setCollapsed] = useState(false);
  const pan = useRef(new Animated.ValueXY({ x: SCREEN.width - 130, y: 200 })).current;

  const panResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderMove: Animated.event([null, { dx: pan.x, dy: pan.y }], { useNativeDriver: false }),
    onPanResponderRelease: () => pan.extractOffset(),
  });

  const dragon = rounds.filter(r => r.result === 'Dragon').length;
  const tiger = rounds.filter(r => r.result === 'Tiger').length;
  const total = rounds.length;

  const pickColor = prediction?.pick === 'Dragon' ? '#e74c3c' : prediction?.pick === 'Tiger' ? '#3498db' : '#2ecc71';

  return (
    <Animated.View style={[styles.hud, { transform: pan.getTranslateTransform() }]} {...panResponder.panHandlers}>
      <TouchableOpacity onPress={() => setCollapsed(!collapsed)} style={styles.header}>
        <Text style={styles.headerText}>🎯 HUD</Text>
        <Text style={styles.collapseBtn}>{collapsed ? '▼' : '▲'}</Text>
      </TouchableOpacity>

      {!collapsed && (
        <View style={styles.body}>
          {prediction ? (
            <>
              <Text style={[styles.pick, { color: pickColor }]}>
                {prediction.pick === 'Dragon' ? '🐉' : prediction.pick === 'Tiger' ? '🐯' : '🤝'} {prediction.pick}
              </Text>
              <Text style={styles.conf}>{prediction.confidence}%</Text>
            </>
          ) : (
            <Text style={styles.noData}>—</Text>
          )}
          <View style={styles.miniStats}>
            <Text style={styles.miniD}>D:{dragon}</Text>
            <Text style={styles.miniT}>T:{tiger}</Text>
            <Text style={styles.miniTotal}>/{total}</Text>
          </View>
        </View>
      )}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  hud: { position: 'absolute', backgroundColor: 'rgba(10,10,10,0.92)', borderRadius: 14, borderWidth: 1, borderColor: '#333', minWidth: 110, zIndex: 999 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 8, borderBottomWidth: 1, borderBottomColor: '#222' },
  headerText: { color: '#fff', fontSize: 12, fontWeight: 'bold' },
  collapseBtn: { color: '#888', fontSize: 10 },
  body: { padding: 10, alignItems: 'center' },
  pick: { fontSize: 16, fontWeight: 'bold' },
  conf: { color: '#aaa', fontSize: 12, marginTop: 2 },
  noData: { color: '#555', fontSize: 20 },
  miniStats: { flexDirection: 'row', marginTop: 6, gap: 4 },
  miniD: { color: '#e74c3c', fontSize: 11 },
  miniT: { color: '#3498db', fontSize: 11 },
  miniTotal: { color: '#666', fontSize: 11 },
});
