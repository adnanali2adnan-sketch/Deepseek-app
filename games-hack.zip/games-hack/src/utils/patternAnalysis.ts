import type { Round, Prediction, ResultType } from '../types';

export function analyzePattern(rounds: Round[]): Prediction {
  if (rounds.length < 3) {
    const last = rounds[rounds.length - 1].result;
    return { pick: last === 'Dragon' ? 'Tiger' : 'Dragon', confidence: 52, reason: 'Not enough data — basic counter', pattern: 'basic' };
  }

  const results = rounds.map(r => r.result);
  const last = results[results.length - 1];
  const last2 = results[results.length - 2];
  const last3 = results[results.length - 3];

  // Streak detection
  let streak = 1;
  for (let i = results.length - 2; i >= 0; i--) {
    if (results[i] === last) streak++;
    else break;
  }

  // If streak >= 3 — predict reversal
  if (streak >= 3 && last !== 'Tie') {
    const reverse: ResultType = last === 'Dragon' ? 'Tiger' : 'Dragon';
    return { pick: reverse, confidence: Math.min(75 + streak * 3, 88), reason: `${last} ${streak}x streak — reversal likely`, pattern: 'streak-reversal' };
  }

  // Alternating pattern
  if (last !== 'Tie' && last2 !== 'Tie' && last !== last2 && last2 !== last3 && last3 !== last) {
    return { pick: last === 'Dragon' ? 'Tiger' : 'Dragon', confidence: 72, reason: 'Alternating D-T pattern detected', pattern: 'alternating' };
  }

  // Frequency analysis
  const total = rounds.length;
  const dCount = results.filter(r => r === 'Dragon').length;
  const tCount = results.filter(r => r === 'Tiger').length;
  const dPct = dCount / total;
  const tPct = tCount / total;

  if (dPct > 0.6) return { pick: 'Dragon', confidence: Math.round(55 + dPct * 20), reason: `Dragon dominant (${Math.round(dPct*100)}%)`, pattern: 'frequency' };
  if (tPct > 0.6) return { pick: 'Tiger', confidence: Math.round(55 + tPct * 20), reason: `Tiger dominant (${Math.round(tPct*100)}%)`, pattern: 'frequency' };

  // Last result counter
  const pick: ResultType = last === 'Dragon' ? 'Tiger' : last === 'Tiger' ? 'Dragon' : 'Dragon';
  return { pick, confidence: 55, reason: 'No strong pattern — counter last', pattern: 'counter' };
}
