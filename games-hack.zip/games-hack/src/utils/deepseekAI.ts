import axios from 'axios';
import type { Round, Prediction, ResultType } from '../types';

const DEEPSEEK_API_URL = 'https://api.deepseek.com/chat/completions';

export async function getDeepSeekPrediction(rounds: Round[]): Promise<Prediction | null> {
  const apiKey = process.env.DEEPSEEK_API_KEY;
  if (!apiKey || rounds.length < 5) return null;

  const history = rounds.slice(-20).map(r => r.result).join(', ');

  try {
    const res = await axios.post(DEEPSEEK_API_URL, {
      model: 'deepseek-chat',
      messages: [
        {
          role: 'system',
          content: 'You are a Dragon Tiger baccarat pattern analyst. Given a sequence of results (Dragon/Tiger/Tie), predict the next result. Respond ONLY with JSON: {"pick":"Dragon"|"Tiger"|"Tie","confidence":50-95,"reason":"short reason"}'
        },
        {
          role: 'user',
          content: `Last ${rounds.slice(-20).length} results: ${history}. What is next?`
        }
      ],
      max_tokens: 100,
      temperature: 0.3,
    }, {
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      timeout: 8000,
    });

    const content = res.data.choices[0]?.message?.content ?? '';
    const match = content.match(/\{.*\}/s);
    if (!match) return null;
    const data = JSON.parse(match[0]);
    return {
      pick: data.pick as ResultType,
      confidence: data.confidence,
      reason: `🤖 AI: ${data.reason}`,
      pattern: 'deepseek-ai',
    };
  } catch {
    return null;
  }
}
