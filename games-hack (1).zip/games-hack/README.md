# Dragon Tiger AI - Android APK

## Features
- Floating draggable HUD (PILOT style)
- Casino Road Analysis (Big Eye Boy, Small Road, Cockroach)
- Real-time DeepSeek AI response (add your API key in app settings ⚙)
- Dragon/Tiger/Tie quick entry
- Undo / Reset
- Full history view

## DeepSeek API Key
1. Get key from: platform.deepseek.com
2. Open app → tap ⚙ in HUD header → paste key → Save

## Build APK
Push to GitHub with build.yml → GitHub Actions → APK ready
