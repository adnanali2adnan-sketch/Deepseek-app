import React, { useState, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Animated, PanResponder, Dimensions, ScrollView, TextInput } from 'react-native';
import type { Prediction, Round } from '../types';

interface Props { prediction: Prediction|null; rounds: Round[]; onAdd:(r:'Dragon'|'Tiger'|'Tie')=>void; onUndo:()=>void; onReset:()=>void; apiKey:string; onApiKeyChange:(k:string)=>void; aiText:string; aiLoading:boolean; onRefreshAI:()=>void; }

const SW = Dimensions.get('window').width;
const C = { Dragon:'#27ae60', Tiger:'#e74c3c', Tie:'#8e44ad' };

export default function FloatingHUD({ prediction, rounds, onAdd, onUndo, onReset, apiKey, onApiKeyChange, aiText, aiLoading, onRefreshAI }: Props) {
  const [collapsed, setCollapsed] = useState(false);
  const [showKey, setShowKey] = useState(false);
  const pan = useRef(new Animated.ValueXY({ x: 10, y: 80 })).current;
  const pr = PanResponder.create({
    onStartShouldSetPanResponder:()=>true,
    onPanResponderMove:Animated.event([null,{dx:pan.x,dy:pan.y}],{useNativeDriver:false}),
    onPanResponderRelease:()=>pan.extractOffset(),
  });

  const d=rounds.filter(r=>r.result==='Dragon').length, t=rounds.filter(r=>r.result==='Tiger').length, tie=rounds.filter(r=>r.result==='Tie').length, total=rounds.length;
  const lastRounds = rounds.slice(-6).reverse();

  return (
    <Animated.View style={[s.hud,{transform:pan.getTranslateTransform()}]}>
      {/* Header - drag handle */}
      <View {...pr.panHandlers} style={s.hdr}>
        <View style={s.dot}/><Text style={s.hdrIcon}>🎮</Text>
        <Text style={s.hdrTxt}>PILOT</Text>
        <TouchableOpacity onPress={()=>setShowKey(!showKey)} style={s.keyBtn}>
          <Text style={[s.keyBtnTxt,{color:apiKey?'#27ae60':'#666'}]}>⚙</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={()=>setCollapsed(!collapsed)}>
          <Text style={s.colBtn}>{collapsed?'▼':'▲'}</Text>
        </TouchableOpacity>
      </View>

      {!collapsed && <>
        {/* API Key Input */}
        {showKey && (
          <View style={s.keySection}>
            <Text style={s.keyLabel}>DEEPSEEK API KEY</Text>
            <TextInput value={apiKey} onChangeText={onApiKeyChange} placeholder="sk-..." placeholderTextColor="#444" style={s.keyInput} secureTextEntry/>
          </View>
        )}

        <View style={s.body}>
          {/* Status */}
          <View style={s.statusRow}>
            <Text style={s.statusIcon}>📁</Text>
            <Text style={s.statusTxt}>COLLECTING</Text>
            <Text style={s.roundCount}>{total} rounds</Text>
          </View>

          {/* Next Bet + Streak */}
          <View style={s.row2}>
            <View style={[s.box2,{borderColor:'#1f2937'}]}>
              <Text style={s.boxLabel}>NEXT BET</Text>
              <Text style={[s.boxVal,{color:prediction?C[prediction.pick]:'#555'}]}>
                {prediction?(prediction.pick==='Dragon'?'🐉 D':'🐯 T'):'WAIT'}
              </Text>
            </View>
            <View style={[s.box2,{borderColor:'#1e2060',backgroundColor:'#0f1127'}]}>
              <Text style={s.boxLabel}>STREAK</Text>
              <Text style={[s.boxVal,{color:'#aaa'}]}>
                {prediction?.pattern==='streak'?prediction.reason.split(' ')[1]||'—':'NONE'}
              </Text>
            </View>
          </View>

          {/* D% T% X% */}
          <View style={s.row3}>
            {([['D%',d,C.Dragon],['T%',t,C.Tiger],['X%',tie,C.Tie]] as const).map(([lbl,cnt,col])=>(
              <View key={lbl} style={[s.box3,{borderColor:col+'44',backgroundColor:col+'18'}]}>
                <Text style={[s.box3Label,{color:col}]}>{lbl}</Text>
                <Text style={[s.box3Val,{color:col}]}>{total?Math.round(cnt/total*100):0}%</Text>
              </View>
            ))}
          </View>

          {/* Reason */}
          {prediction && <Text style={s.reasonTxt} numberOfLines={2}>{prediction.reason}</Text>}

          {/* Last Rounds */}
          <View style={s.lastSection}>
            <Text style={s.lastLabel}>LAST ROUNDS</Text>
            <View style={s.bubbles}>
              {lastRounds.length ? lastRounds.map((r,i)=>(
                <View key={r.id} style={[s.bubble,{backgroundColor:C[r.result],width:i===0?24:20,height:i===0?24:20,borderRadius:12}]}>
                  <Text style={s.bubbleTxt}>{r.result[0]}</Text>
                </View>
              )):<Text style={s.noRounds}>None</Text>}
            </View>
          </View>

          {/* Quick Entry */}
          <Text style={s.qeLabel}>QUICK ENTRY</Text>
          <View style={s.qeRow}>
            {(['Dragon','Tie','Tiger'] as const).map(r=>(
              <TouchableOpacity key={r} onPress={()=>onAdd(r)} style={[s.qeBtn,{backgroundColor:C[r]}]}>
                <Text style={s.qeEmoji}>{r==='Dragon'?'🐉':r==='Tiger'?'🐯':'🟣'}</Text>
                <Text style={s.qeBtnTxt}>{r==='Dragon'?'D':r==='Tiger'?'T':'TIE'}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* DeepSeek */}
          <View style={s.aiSection}>
            <View style={s.aiHeader}>
              <View style={[s.aiDot,{backgroundColor:apiKey?'#3498db':'#444'}]}/>
              <Text style={[s.aiTitle,{color:apiKey?'#3498db':'#555'}]}>DEEPSEEK {apiKey?'AI':'(no key)'}</Text>
              {apiKey&&<TouchableOpacity onPress={onRefreshAI} style={s.refreshBtn}><Text style={s.refreshTxt}>{aiLoading?'⏳':'🔄'}</Text></TouchableOpacity>}
            </View>
            <ScrollView style={s.aiBox} nestedScrollEnabled>
              <Text style={s.aiTxt}>{aiLoading?'Analyzing...':aiText}</Text>
            </ScrollView>
          </View>

          {/* Undo Reset */}
          <View style={s.actionRow}>
            <TouchableOpacity onPress={onUndo} disabled={!rounds.length} style={[s.actionBtn,{opacity:rounds.length?1:0.3}]}>
              <Text style={s.actionTxt}>↩ UNDO</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={onReset} disabled={!rounds.length} style={[s.actionBtn,s.resetBtn,{opacity:rounds.length?1:0.3}]}>
              <Text style={[s.actionTxt,{color:'#e74c3c'}]}>🗑 RESET</Text>
            </TouchableOpacity>
          </View>
        </View>
      </>}
    </Animated.View>
  );
}

const s = StyleSheet.create({
  hud:{position:'absolute',width:200,backgroundColor:'rgba(14,16,28,0.97)',borderRadius:10,borderWidth:1,borderColor:'rgba(255,255,255,0.1)',zIndex:999,shadowColor:'#000',shadowOpacity:0.8,shadowRadius:20},
  hdr:{flexDirection:'row',alignItems:'center',gap:4,padding:5,backgroundColor:'rgba(255,255,255,0.04)',borderBottomWidth:1,borderBottomColor:'rgba(255,255,255,0.06)'},
  dot:{width:6,height:6,borderRadius:3,backgroundColor:'#f1c40f'},
  hdrIcon:{fontSize:12},hdrTxt:{fontWeight:'900',letterSpacing:2,fontSize:11,flex:1,color:'#fff'},
  keyBtn:{padding:2},keyBtnTxt:{fontSize:13,fontWeight:'900'},
  colBtn:{color:'#666',fontSize:10,paddingHorizontal:4},
  keySection:{padding:'6px 8px',backgroundColor:'#0d0f1a',borderBottomWidth:1,borderBottomColor:'rgba(255,255,255,0.06)'},
  keyLabel:{fontSize:8,color:'#555',marginBottom:4},
  keyInput:{backgroundColor:'#1a1c2e',borderWidth:1,borderColor:'#333',borderRadius:5,padding:4,color:'#fff',fontSize:10},
  body:{padding:6,gap:5},
  statusRow:{flexDirection:'row',alignItems:'center',gap:4},
  statusIcon:{fontSize:11},statusTxt:{fontWeight:'700',color:'#ccc',fontSize:9,flex:1},roundCount:{fontSize:8,color:'#555'},
  row2:{flexDirection:'row',gap:4},
  box2:{flex:1,backgroundColor:'#111827',borderRadius:6,padding:5,borderWidth:1},
  boxLabel:{fontSize:8,color:'#444',letterSpacing:1,marginBottom:2},
  boxVal:{fontSize:13,fontWeight:'900',lineHeight:16},
  row3:{flexDirection:'row',gap:3},
  box3:{flex:1,borderRadius:5,padding:4,alignItems:'center',borderWidth:1},
  box3Label:{fontSize:7,fontWeight:'700',marginBottom:1},box3Val:{fontSize:14,fontWeight:'900'},
  reasonTxt:{fontSize:9,color:'#777',lineHeight:13},
  lastSection:{gap:3},lastLabel:{fontSize:8,color:'#333'},
  bubbles:{flexDirection:'row',gap:3,flexWrap:'wrap'},
  bubble:{alignItems:'center',justifyContent:'center'},bubbleTxt:{color:'#fff',fontWeight:'700',fontSize:9},
  noRounds:{color:'#333',fontSize:9},
  qeLabel:{fontSize:8,color:'#333'},
  qeRow:{flexDirection:'row',gap:3},
  qeBtn:{flex:1,borderRadius:6,paddingVertical:6,alignItems:'center',gap:1},
  qeEmoji:{fontSize:14},qeBtnTxt:{color:'#fff',fontWeight:'800',fontSize:9},
  aiSection:{gap:4},
  aiHeader:{flexDirection:'row',alignItems:'center',gap:4},
  aiDot:{width:6,height:6,borderRadius:3},
  aiTitle:{fontSize:8,fontWeight:'800',letterSpacing:1,flex:1},
  refreshBtn:{padding:2},refreshTxt:{fontSize:11},
  aiBox:{backgroundColor:'#080b14',borderRadius:6,padding:6,borderWidth:1,borderColor:'#1a2030',maxHeight:70},
  aiTxt:{fontSize:10,color:'#aaa',lineHeight:15},
  actionRow:{flexDirection:'row',gap:4},
  actionBtn:{flex:1,backgroundColor:'rgba(255,255,255,0.05)',borderWidth:1,borderColor:'rgba(255,255,255,0.08)',borderRadius:6,padding:6,alignItems:'center'},
  resetBtn:{backgroundColor:'rgba(231,76,60,0.08)',borderColor:'rgba(231,76,60,0.2)'},
  actionTxt:{color:'#bbb',fontSize:10,fontWeight:'700'},
});
