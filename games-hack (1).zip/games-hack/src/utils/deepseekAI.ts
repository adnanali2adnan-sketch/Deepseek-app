import axios from 'axios';
import type { Round, Prediction, ResultType } from '../types';
const DEEPSEEK_URL = 'https://api.deepseek.com/chat/completions';
export async function getDeepSeekPrediction(rounds: Round[], apiKey: string): Promise<string|null> {
  if (!apiKey || rounds.length < 3) return null;
  const history = rounds.slice(-20).map(r=>r.result).join(' → ');
  try {
    const res = await axios.post(DEEPSEEK_URL, {
      model:'deepseek-chat',
      messages:[
        {role:'system',content:'You are a Dragon Tiger baccarat pattern expert. Analyze and predict next result. Be brief (3-4 lines). Write in simple English or Urdu.'},
        {role:'user',content:`Last ${Math.min(rounds.length,20)} results: ${history}\n\nWhat is next likely result and why?`}
      ],
      max_tokens:150,temperature:0.4,
    },{headers:{Authorization:`Bearer ${apiKey}`,'Content-Type':'application/json'},timeout:10000});
    return res.data.choices?.[0]?.message?.content ?? null;
  } catch { return null; }
}
