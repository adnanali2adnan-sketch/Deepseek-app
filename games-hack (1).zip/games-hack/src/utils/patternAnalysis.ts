import type { Round, Prediction, ResultType } from '../types';
type Side = 'Dragon' | 'Tiger';
function buildBigRoad(rounds: Round[]): Side[][] {
  const cols: Side[][] = [];
  for (const r of rounds) {
    if (r.result === 'Tie') continue;
    const s = r.result as Side;
    if (!cols.length || cols[cols.length-1][0] !== s) cols.push([s]);
    else cols[cols.length-1].push(s);
  }
  return cols;
}
function signal(cols: Side[][], offset: number): 'red'|'blue'|null {
  if (cols.length < offset+1) return null;
  return cols[cols.length-1].length >= cols[cols.length-1-offset].length ? 'red' : 'blue';
}
export function analyzePattern(rounds: Round[]): Prediction {
  if (!rounds.length) return { pick:'Dragon', reason:'No data', pattern:'none' };
  const cols = buildBigRoad(rounds);
  const last = rounds.filter(r=>r.result!=='Tie').slice(-1)[0];
  if (!last) return { pick:'Dragon', reason:'No D/T yet', pattern:'none' };
  const lastSide = last.result as Side;
  const opp: Side = lastSide==='Dragon'?'Tiger':'Dragon';
  let sv=0, wv=0;
  [signal(cols,1),signal(cols,2),signal(cols,3)].forEach(s=>{if(s==='red')sv++;else if(s==='blue')wv++;});
  let streak=1;
  const sides=rounds.filter(r=>r.result!=='Tie');
  for(let i=sides.length-2;i>=0;i--){if(sides[i].result===lastSide)streak++;else break;}
  if(cols.length<3){
    if(streak>=3) return {pick:opp,reason:`${lastSide} ${streak}× streak — reversal`,pattern:'streak'};
    if(streak===2) return {pick:lastSide,reason:`${lastSide} 2× — streak continue`,pattern:'streak'};
    const d=rounds.filter(r=>r.result==='Dragon').length,t=rounds.filter(r=>r.result==='Tiger').length;
    return {pick:d>=t?'Dragon':'Tiger',reason:'Frequency analysis',pattern:'frequency'};
  }
  if(sv>=2) return {pick:lastSide,reason:`Roads: ${lastSide} continue hoga`,pattern:'road'};
  if(wv>=2) return {pick:opp,reason:`Roads: ${opp} switch`,pattern:'road'};
  if(streak>=3) return {pick:opp,reason:`${streak}× streak → reversal`,pattern:'streak'};
  const d=rounds.filter(r=>r.result==='Dragon').length,t=rounds.filter(r=>r.result==='Tiger').length;
  return {pick:d>=t?'Dragon':'Tiger',reason:'Roads split → frequency',pattern:'frequency'};
}
