import React, { useState, useEffect } from 'react';
import { View, StyleSheet, SafeAreaView, StatusBar, ScrollView, Text } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import FloatingHUD from './src/components/FloatingHUD';
import { analyzePattern } from './src/utils/patternAnalysis';
import { getDeepSeekPrediction } from './src/utils/deepseekAI';
import type { Round, Prediction } from './src/types';

const C = { Dragon:'#27ae60', Tiger:'#e74c3c', Tie:'#8e44ad' };

export default function App() {
  const [rounds, setRounds] = useState<Round[]>([]);
  const [nextId, setNextId] = useState(1);
  const [prediction, setPrediction] = useState<Prediction|null>(null);
  const [apiKey, setApiKey] = useState('');
  const [aiText, setAiText] = useState('Rounds add karo → analysis shuru ho');
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => { AsyncStorage.getItem('ds_key').then(k => k && setApiKey(k)); }, []);

  const handleApiKeyChange = async (k: string) => {
    setApiKey(k);
    await AsyncStorage.setItem('ds_key', k);
  };

  const add = (result: 'Dragon'|'Tiger'|'Tie') => {
    const nr = [...rounds, { id: nextId, result, timestamp: new Date() }];
    setRounds(nr);
    setNextId(id => id+1);
    const pred = analyzePattern(nr);
    setPrediction(pred);
    if (apiKey && nr.length >= 3) refreshAI(nr, apiKey);
  };

  const undo = () => {
    const nr = rounds.slice(0,-1);
    setRounds(nr);
    setPrediction(nr.length ? analyzePattern(nr) : null);
  };

  const reset = () => { setRounds([]); setPrediction(null); setAiText('Rounds add karo → analysis shuru ho'); setNextId(1); };

  const refreshAI = async (r: Round[], key: string) => {
    setAiLoading(true);
    const txt = await getDeepSeekPrediction(r, key);
    setAiText(txt ?? `${prediction?.reason || '—'}\n\nDeepSeek key check karo`);
    setAiLoading(false);
  };

  const d=rounds.filter(r=>r.result==='Dragon').length, t=rounds.filter(r=>r.result==='Tiger').length, tie=rounds.filter(r=>r.result==='Tie').length;

  return (
    <SafeAreaView style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0c14"/>

      {/* Background history view */}
      <View style={s.bg}>
        <Text style={s.bgTitle}>🐉 Dragon Tiger Tracker</Text>
        <View style={s.statsRow}>
          {[['Dragon',d,'#27ae60'],['Tiger',t,'#e74c3c'],['Tie',tie,'#8e44ad']].map(([l,c,col])=>(
            <View key={l as string} style={[s.statCard,{borderColor:col as string}]}>
              <Text style={[s.statNum,{color:col as string}]}>{c as number}</Text>
              <Text style={s.statLbl}>{l as string}</Text>
            </View>
          ))}
        </View>
        <Text style={s.hint}>Floating HUD se rounds enter karo ↗</Text>
        <ScrollView style={s.histScroll} showsVerticalScrollIndicator={false}>
          <View style={s.bubbles}>
            {[...rounds].reverse().map((r,i)=>(
              <View key={r.id} style={[s.bubble,{backgroundColor:C[r.result],width:i===0?36:30,height:i===0?36:30,borderRadius:18,borderWidth:i===0?2:0,borderColor:'rgba(255,255,255,0.4)'}]}>
                <Text style={s.bTxt}>{r.result[0]}</Text>
              </View>
            ))}
          </View>
        </ScrollView>
      </View>

      {/* Floating HUD */}
      <FloatingHUD
        prediction={prediction} rounds={rounds}
        onAdd={add} onUndo={undo} onReset={reset}
        apiKey={apiKey} onApiKeyChange={handleApiKeyChange}
        aiText={aiText} aiLoading={aiLoading}
        onRefreshAI={()=>refreshAI(rounds,apiKey)}
      />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container:{flex:1,backgroundColor:'#0a0c14'},
  bg:{flex:1,padding:16},
  bgTitle:{color:'#fff',fontSize:22,fontWeight:'900',textAlign:'center',marginBottom:16,marginTop:8},
  statsRow:{flexDirection:'row',gap:10,marginBottom:16},
  statCard:{flex:1,backgroundColor:'#111',borderRadius:12,padding:12,alignItems:'center',borderWidth:1},
  statNum:{fontSize:28,fontWeight:'900'},
  statLbl:{color:'#666',fontSize:11,marginTop:2},
  hint:{color:'#333',fontSize:12,textAlign:'center',marginBottom:12},
  histScroll:{flex:1},
  bubbles:{flexDirection:'row',flexWrap:'wrap',gap:6},
  bubble:{alignItems:'center',justifyContent:'center'},
  bTxt:{color:'#fff',fontWeight:'900',fontSize:13},
});
